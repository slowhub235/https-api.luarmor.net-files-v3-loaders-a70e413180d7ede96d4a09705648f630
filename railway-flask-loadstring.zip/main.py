import os
import secrets
from datetime import datetime

from flask import Flask, request, render_template, abort, url_for, Response
from sqlalchemy import create_engine, text

# --- Config ---
def get_database_url():
    # Prefer DATABASE_URL (e.g., Railway Postgres). Fallback to local SQLite file.
    db_url = os.getenv("DATABASE_URL")
    if db_url:
        # Heroku/Railway style URLs may start with "postgres://"; SQLAlchemy needs "postgresql://"
        if db_url.startswith("postgres://"):
            db_url = db_url.replace("postgres://", "postgresql://", 1)
        return db_url
    return "sqlite:///scripts.db"

DATABASE_URL = get_database_url()

# Initialize Flask
app = Flask(__name__)

# Create SQLAlchemy engine
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# Initialize DB schema
with engine.begin() as conn:
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS scripts (
            id TEXT PRIMARY KEY,
            code TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL
        )
    """))

def save_script(script_id: str, code: str):
    with engine.begin() as conn:
        conn.execute(
            text("INSERT INTO scripts (id, code, created_at) VALUES (:id, :code, :created_at)"),
            {"id": script_id, "code": code, "created_at": datetime.utcnow()},
        )

def get_script(script_id: str):
    with engine.begin() as conn:
        row = conn.execute(text("SELECT code FROM scripts WHERE id = :id"), {"id": script_id}).fetchone()
        return row[0] if row else None

@app.route("/", methods=["GET", "POST"])
def index():
    loadstring_code = None
    error = None
    if request.method == "POST":
        code = (request.form.get("code") or "").strip()
        if not code:
            error = "Please enter some Lua code."
        else:
            script_id = secrets.token_hex(8)
            save_script(script_id, code)
            # Generate absolute URL using Flask so you don't have to hardcode the domain
            raw_url = url_for("raw_script", script_id=script_id, _external=True)
            loadstring_code = f'loadstring(game:HttpGet("{raw_url}"))()'
    return render_template("index.html", loadstring_code=loadstring_code, error=error)

@app.route("/raw/<script_id>")
def raw_script(script_id: str):
    code = get_script(script_id)
    if not code:
        abort(404, "Script not found")
    # Serve as text/plain so Roblox can fetch it
    return Response(code, mimetype="text/plain")

@app.route("/view/<script_id>")
def view_script(script_id: str):
    """Optional: simple viewer page (not linked in UI, but accessible by URL)."""
    code = get_script(script_id)
    if not code:
        abort(404, "Script not found")
    raw_url = url_for("raw_script", script_id=script_id, _external=True)
    ls = f'loadstring(game:HttpGet("{raw_url}"))()'
    return f"<pre>{ls}</pre>"

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8080"))
    app.run(host="0.0.0.0", port=port, debug=False)