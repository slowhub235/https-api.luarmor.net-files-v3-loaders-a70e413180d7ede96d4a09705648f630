# Railway Flask Loadstring Creator

A Flask site that generates **hidden URLs** containing your Lua script and shows a ready-to-copy:
```
loadstring(game:HttpGet("https://your-domain/raw/<id>"))()
```
When executed in Roblox, it fetches the raw script and runs it.

## Features
- Clean Bootstrap UI to paste Lua code and get a loadstring
- Hidden endpoint `/raw/<id>` (no UI, text/plain)
- Uses absolute URLs with `url_for(..., _external=True)` so you **never** hardcode your domain
- **Persistence** via SQLite (default) or PostgreSQL (recommended on Railway)

## Deploy to Railway (easiest)
1. Create a new Railway project and connect a GitHub repo with these files.
2. Railway auto-detects Python; set your Start Command to either:
   - `python main.py` (simple), or
   - `gunicorn main:app` (production-ready)
3. Visit your Railway domain. Done!

### Optional: PostgreSQL (Recommended for persistence across redeploys)
1. In your Railway project, add a **PostgreSQL** plugin.
2. Copy its `DATABASE_URL` and add it to your project's environment variables.
3. The app will auto-use Postgres if `DATABASE_URL` is set.

## Local Dev
```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .\.venv\Scripts\activate
pip install -r requirements.txt
python main.py
# visit http://localhost:8080
```

## Files
- `main.py` — Flask app with SQLAlchemy, SQLite/Postgres support
- `templates/index.html` — Bootstrap UI
- `requirements.txt` — deps (Flask, SQLAlchemy, Gunicorn, psycopg2)
- `README.md` — docs